export default function Item(props) {
    return (
        <li>
            {props.conteudo}
        </li>
    )
}