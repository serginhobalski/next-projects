import '../styles/globals.css'
import './css/integracao1.css'

function MyApp({ Component, pageProps }) {
  return <Component {...pageProps} />
}

export default MyApp
