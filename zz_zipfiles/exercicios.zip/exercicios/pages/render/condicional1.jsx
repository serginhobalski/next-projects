import SomentePar from "../../components/SomentePar";

export default function condicional1() {
    return (
        <div>
            <SomentePar numero={1} />
            <SomentePar numero={2} />
            <SomentePar numero={3} />
            <SomentePar numero={4} />
            <SomentePar numero={5} />
            <SomentePar numero={6} />
            <SomentePar numero={7} />
            <SomentePar numero={8} />
            <SomentePar numero={9} />
            <SomentePar numero={10} />
        </div>
    )
}