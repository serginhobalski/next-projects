import SomaUm from "../../components/SomaUm";

export default function propsSomenteLeitura() {
    return <SomaUm numero={99} />
}