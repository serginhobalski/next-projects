export default function teste() {
    return <h1>Teste</h1>
}