export default function jsx3() {
    return (
        <div>
            <h1>JSX #03</h1>
        </div>
    )
}