// JSX
export default function jsx1Diferente() {
    return (
        <div>
            <h1>JSX #01</h1>
        </div>
    )
}