export default function jsx2() {
    const conteudo = (
        <div>
            <h1 className="vermelha">JSX #02</h1>
        </div>
    )
    return conteudo
}