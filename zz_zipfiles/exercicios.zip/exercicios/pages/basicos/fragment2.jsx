export default function fragment() {
    return (
        <>
            <h1>Título</h1>
            <h2>Subtítulo</h2>
        </>
    )
}