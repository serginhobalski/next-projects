export default function primeiro() {
    return "Primeiro"
}