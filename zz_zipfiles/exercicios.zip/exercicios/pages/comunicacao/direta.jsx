import Pai from "../../components/direta/Pai";

export default function direta() {
    return (
        <div>
            <Pai familia="Albuquerque" nome="Padrão" />
        </div>
    )
}