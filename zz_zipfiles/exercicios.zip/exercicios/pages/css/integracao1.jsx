// Não posso importar aqui!
// O import foi feito dentro de _app.js

export default function integracao() {
    return (
        <div className="integracao1">
            <div className="vermelha">Texto #01</div>
            <div className="azul">Texto #02</div>
            <div className="branca">Texto #03</div>
        </div>
    )
}