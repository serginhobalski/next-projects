export default function OutraRota() {
    return (
        <div>
            <h1>_Outra Rota</h1>
        </div>
    )
}