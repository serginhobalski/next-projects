export default function OutraRota() {
    return (
        <div>
            <h1>Outra Rota</h1>
        </div>
    )
}